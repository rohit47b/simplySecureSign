import React, { PureComponent } from 'react'


class ForgotPassword extends PureComponent{

    render(){
        return(
            <div>Forgot Password</div>
        )
    }
}

export default ForgotPassword