import PropTypes from 'prop-types';
import React, { PureComponent } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import FileIcon from '@material-ui/icons/InsertDriveFile';
import VideoIcon from '@material-ui/icons/Videocam';
import ChatIcon from '@material-ui/icons/Chat';
import PowerIcon from '@material-ui/icons/PowerSettingsNew';
import Grid from '@material-ui/core/Grid';
import history from 'customHistory'
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import Typography from '@material-ui/core/Typography';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogContent from '@material-ui/core/DialogContent';

const styles = theme => ({
    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9
    },
    [theme.breakpoints.down('sm')]: {
        signClosingWizard: {
            padding: '20px',
        },
        rightSidebarContainer: {
            paddingTop: '0px',
        },
        heading: {
            marginBottom: '20%',
        }
    },
    typography: {
        margin: theme.spacing.unit * 2,
    },
    avatar: {
        width: 35,
        height: 35,
    }
});


class ChatRoomMobileAction extends PureComponent {
    state = {
        open: false,
        
      };
    
      handleClickOpen = () => {
        this.setState({
          open: true,
        });
      };
    
      handleClose = value => {
        this.setState({ selectedValue: value, open: false });
      };
   
    render() {
        const { classes } = this.props;   
        const { open } = this.state;
        return (
            <Grid container className="mobile-bottom-action-btn justify-content-center" justify="space-evenly" alignItems="center">
                  <Grid item xs={3} sm={3} className="nav-link">
                <Avatar onClick={() => history.push('/app/remote-sign/signing-room')} className={classes.avatar + " bottom-nav-icon active-btn"} >
                    <FileIcon  />
                </Avatar>
                </Grid>
                <Grid item xs={3} sm={3} className="nav-link">
                <Avatar  onClick={() => history.push('/app/remote-sign/video-chat')} className={classes.avatar + " bottom-nav-icon"}>
                    <VideoIcon />
                </Avatar>
                </Grid>
                <Grid item xs={3} sm={3} className="nav-link">
                <Avatar onClick={() => history.push('/app/remote-sign/online-chat')} className={classes.avatar + " bottom-nav-icon"}>
                    <ChatIcon />
                </Avatar>
                </Grid>
                <Grid item xs={3} sm={3} className="nav-link">
                <Avatar  onClick={this.handleClickOpen}  className={classes.avatar + " bottom-nav-icon"}>
                    <PowerIcon />
                </Avatar>
                </Grid>
                <Dialog
          open={open}
          onClose={this.handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogContent>
            <DialogContentText id="alert-dialog-description">
              Do you want to close this chat.
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => history.push('/app/remote-sign/welcome')} color="primary" className="btn btn-primary btn-sm">
              Yes
            </Button>
            <Button onClick={this.handleClose} color="primary" className="btn btn-gray btn-sm" autoFocus>
              No
            </Button>
          </DialogActions>
        </Dialog>
            </Grid>
        )
    }
}

ChatRoomMobileAction.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(ChatRoomMobileAction)
