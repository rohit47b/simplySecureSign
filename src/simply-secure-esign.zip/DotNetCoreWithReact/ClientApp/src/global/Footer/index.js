import React from 'react';

const Footer=(props)=>  {
    return (
      <div>
        <footer className="bx-footer" style={{ textAlign: "center" }}>
          ---------------------------------------<br />
          Footer
          <span className="bx-copyright-text">&copy; 2018, Secberus.com</span>
        </footer>
      </div>
    );
}

export default Footer;
