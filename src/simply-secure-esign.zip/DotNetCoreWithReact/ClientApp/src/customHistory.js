import { createBrowserHistory } from 'history'
 
const history = createBrowserHistory({
    basname: ''
  })


  export default history